from Anilist.auth.auth import Auth
from Anilist.client import QueryClient, MutationClient
from Anilist.scheme import Scheme
